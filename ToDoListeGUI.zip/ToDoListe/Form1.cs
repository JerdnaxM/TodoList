﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ToDoListe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadToDoList()
        {
            checkedListBox1.Items.Clear(); // ListBox leeren

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("ToDoListe.xml"); // XML-Datei laden
            

            XmlNodeList eintraege = xmlDoc.SelectNodes("//Eintrag");
            foreach (XmlNode eintrag in eintraege)
            {
                checkedListBox1.Items.Add(eintrag.InnerText); // Einträge in ListBox hinzufügen
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(textBox1.Text)) // Prüfen, ob Eingabe leer ist
            {
                checkedListBox1.Items.Add(textBox1.Text); // Eintrag zur ListBox hinzufügen
                textBox1.Clear(); // Eingabefeld leeren
            }
        }


        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadToDoList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedItem != null && !string.IsNullOrWhiteSpace(textBox1.Text)) // Prüfen, ob ein Eintrag ausgewählt ist
            {
                int index = checkedListBox1.SelectedIndex; // Index des ausgewählten Eintrags
                checkedListBox1.Items[index] = textBox1.Text; // Text ersetzen
                textBox1.Clear(); // Eingabefeld leeren
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedItem != null) // Prüfen, ob ein Eintrag ausgewählt ist
            {
                checkedListBox1.Items.Remove(checkedListBox1.SelectedItem); // Ausgewählten Eintrag entfernen
            }
        }

    }
}
    

